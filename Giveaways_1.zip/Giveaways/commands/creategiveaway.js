const Base = require('../base/Command');
const Discord = require('discord.js');
// const db = require('../utils/db.js');
const timestring = require('timestring');

class CreateGiveaway extends Base {
  constructor (client) {
    super(client, {
      name: 'creategiveaway',
      description: 'Starts an giveaway.',
      usage: 'creategiveaway',
      permission: 'ADMINISTRATOR',
      aliases: ['createg', 'newgiveaway', 'new', 'start']
    });
  }

  run (message, args) {
    const client = this.client;
    message.channel.send(embed('Please write your channel!')).then(msg => {
      channel(message).then(giveawaychannel => {
        msg.edit(embed(`You selected **${giveawaychannel.name}** as channel!`));
        message.channel.send(embed('Please write the duration!\nExample: **2d10m**')).then(msg => {
          duration(message).then(giveawayduration => {
            msg.edit(embed('You selected the duration!'));
            message.channel.send(embed('Please write your giveaway name!')).then(msg => {
              name(message).then(giveawayname => {
                msg.edit(embed(`You selected **${giveawayname}** as giveaway name.`));
                message.channel.send(embed('Please write a description for your giveaway (Write **none** for no description)')).then(msg => {
                  description(message).then(giveawaydescription => {
                    msg.edit(embed(`You selected **${giveawaydescription}** as giveaway description.`));
                    message.channel.send(embed('Please react with an emoji you want to use for the giveaway')).then(msg => {
                      emoji(message, msg).then(giveawayemoji => {
                        if (giveawayemoji.custom) {
                          msg.edit(embed(`You selected ${giveawayemoji} as custom emoji for the giveaway.`));
                        } else {
                          msg.edit(embed(`You selected ${giveawayemoji.name} as emoji for the giveaway.`));
                        }
                        message.channel.send(embed('Please write your win message! \nYou **need** to use {prize} and {winner} in your message! Or you can write **normal** for the default giveaway message!')).then(msg => {
                          winmessage(message).then(giveawaywinmessage => {
                            msg.edit(embed(`You selected **${giveawaywinmessage}** as win message for the giveaway.`));
                            message.channel.send(embed('Please select max winners for the giveaway!')).then(msg => {
                              winners(message).then(giveawaywinners => {
                                msg.edit(`You selected ${giveawaywinners} winners!`);
                                message.channel.send(embed('Do the people need to join a guild before they can enter the guild?\nIf not write **none**. If there is a guild write the name/id of it.')).then(msg => {
                                  guildjoin(message).then(giveawayguildjoin => {
                                    msg.edit(embed(`You selected **${giveawayguildjoin.name ? giveawayguildjoin.name : giveawayguildjoin}** as guild!`));

                                    if (giveawayguildjoin.name) {
                                      message.channel.send(embed('Please write the invite for that guild! You can write **none** to select no invite.')).then(msg => {
                                        invite(message).then(giveawayinvite => {
                                          msg.edit(embed(`You selected ${giveawayinvite || 'none'} as invite for the guild to join!`));

                                          message.channel.send(embed('Creating giveaway...')).then(msg => {
                                            giveawaychannel.send(embed('Giveaway... Loading...'))
                                              .then(giveawaymessage => {
                                                giveawaymessage.react(giveawayemoji);
                                                this.client.giveaway.create(client, giveawayname, giveawaydescription, giveawayduration, giveawaywinmessage, giveawaywinners, giveawaychannel, message.guild, giveawayemoji, giveawayguildjoin, giveawayinvite, giveawaymessage)
                                                  .then(() => msg.edit(embed(`Your giveaway has been created!\n[» Click here to view giveaway!](${giveawaymessage.url})`)))
                                                  .catch(err => {
                                                    msg.edit(embed(`Your giveaway was not made because of:\n${err}`));
                                                    console.log(err.stack);
                                                  });
                                              });
                                          });
                                        });
                                      });
                                    } else {
                                      message.channel.send(embed('Creating giveaway...')).then(msg => {
                                        giveawaychannel.send(embed('Giveaway... Loading...'))
                                          .then(giveawaymessage => {
                                            giveawaymessage.react(giveawayemoji);
                                            this.client.giveaway.create(client, giveawayname, giveawaydescription, giveawayduration, giveawaywinmessage, giveawaywinners, giveawaychannel, message.guild, giveawayemoji, giveawayguildjoin, null, giveawaymessage)
                                              .then(() => msg.edit(embed(`Your giveaway has been created!\n[» Click here to view giveaway!](${giveawaymessage.url})`)))
                                              .catch(err => {
                                                msg.edit(embed(`Your giveaway was not made because of:\n${err}`));
                                                console.log(err.stack);
                                              });
                                          });
                                      });
                                    }
                                  });
                                });
                              });
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
    function channel (message) {
      return new Promise((resolve, reject) => {
        function getChannel () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first();
              if (msg.content.toLowerCase() === 'cancel') {
                collector.stop();
              }
              const channel = msg.mentions.channels.first() || msg.guild.channels.find(x => x.name.toLowerCase() === msg.content || x.id === msg.content);
              if (!channel) {
                message.channel.send(embed('That channel does not exists!'));
                return getChannel();
              }
              resolve(channel);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a channel so the giveaway creation is now canceled!'));
            });
        }
        getChannel();
      });
    }
    function duration (message) {
      return new Promise((resolve, reject) => {
        function getDuration () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first();
              if (msg.content.toLowerCase() === 'cancel') {
                collector.stop();
              }

              let duration;
              try {
                duration = timestring(msg.content);
              } catch (a) {
                duration = 0;
              }

              duration = parseInt(duration);
              if (isNaN(duration) || duration === 0) {
                message.channel.send(embed("I can't parse the duration! Example: **1h10m**."));
                return getDuration();
              }
              if (duration < 60) {
                message.channel.send(embed('Minimum time limit is 1 minute!'));
                return getDuration();
              }

              if (duration > client.maxgiveawayduration) {
                message.channel.send(embed('The maximum time limit is 7 days!'));
              }

              resolve(duration);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a duration of the giveaway so the giveaway creation is now canceled!'));
            });
        }
        getDuration();
      });
    }
    function name (message) {
      return new Promise((resolve, reject) => {
        function getName () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first();
              if (msg.content.toLowerCase() === 'cancel') {
                collector.stop();
              }

              const name = msg.content;
              if (name.length > 256) {
                message.channel.send(embed('The giveaway title can be max 256 chars.'));
                return getName();
              }

              resolve(name);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a name for giveaway so the giveaway creation is now canceled!'));
            });
        }
        getName();
      });
    }

    function description (message) {
      return new Promise((resolve, reject) => {
        function getDescription () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first();
              if (msg.content.toLowerCase() === 'cancel') {
                collector.stop();
              }

              const description = msg.content;
              if (description.length > 1024) {
                message.channel.send(embed('The giveaway title can be max 1024 chars.'));
                return getDescription();
              }

              resolve(description);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose the description of giveaway so the giveaway creation is now canceled!'));
            });
        }
        getDescription();
      });
    }

    function emoji (message, msg) {
      return new Promise((resolve, reject) => {
        function getEmoji () {
          msg.awaitReactions((reaction, user) => user.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const reaction = collected.first();
              const emoji = reaction.emoji;
              if (emoji.id) {
                if (!message.guild.emojis.some(x => x.id === emoji.id)) {
                  message.channel.send(embed('Please select a custom emoji from this guild or a default emoji in discord!'));
                  return getEmoji();
                }
                reaction.custom = true;
                return resolve(emoji);
              }
              resolve(emoji);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose an emoji for the giveaway so the giveaway creation is now canceled!'));
            });
        }
        getEmoji();
      });
    }

    function winmessage (message) {
      return new Promise((resolve, reject) => {
        function getWinMessage () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              let msg = collected.first().content.toLowerCase();
              if (msg === 'cancel') {
                collector.stop();
              }

              if (msg === 'normal') msg = 'Congratulations {winner}! You won {prize}!';

              if (!msg.includes('{winner}')) {
                message.channel.send(embed('Please use {winner} in your win message!'));
                return getWinMessage();
              }

              if (!msg.includes('{prize}')) {
                message.channel.send(embed('Please use {prize} in your win message!'));
                return getWinMessage();
              }

              resolve(msg);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a win message for the giveaway so the giveaway creation is now canceled!'));
            });
        }
        getWinMessage();
      });
    }

    function winners (message) {
      return new Promise((resolve, reject) => {
        function getWinners () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first().content.toLowerCase();
              if (msg === 'cancel') {
                collector.stop();
              }

              const winners = parseInt(msg);
              if (winners > 15 || winners < 1 || isNaN(winners)) {
                message.channel.send(embed('You can choose 1-15 winners for the giveaway!'));
                return getWinners();
              }

              resolve(winners);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose winners of the giveaway so the giveaway creation is now canceled!'));
            });
        }
        getWinners();
      });
    }

    function guildjoin (message) {
      return new Promise((resolve, reject) => {
        function getGuildJoin () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 60000 })
            .then(collected => {
              const msg = collected.first();
              if (msg === 'cancel') {
                collector.stop();
              }

              let guild = msg.content;
              if (guild !== 'none') guild = client.guilds.find(x => x.name === msg.content || x.id === msg.content);

              if (!guild) {
                message.channel.send(embed('I can\'t find that guild!'));
                return getGuildJoin();
              }
              if (guild.id === message.guild.id) {
                message.channel.send(embed('You can\'t choose this guild! Write **none** if you want to select no guild requirement!'));
                return getGuildJoin();
              }

              resolve(guild);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a guild to join so the giveaway creation is now canceled!'));
            });
        }
        getGuildJoin();
      });
    }

    function invite (message) {
      return new Promise((resolve, reject) => {
        function getInvite () {
          const collector = message.channel.awaitMessages(msg => msg.author.id === message.author.id, { max: 1, time: 120000 })
            .then(collected => {
              const msg = collected.first();
              if (msg === 'cancel') {
                collector.stop();
              }
              let invite;
              if (msg.content.toLowerCase() !== 'none') invite = msg.content;

              resolve(invite);
            })
            .catch(() => {
              message.channel.send(embed('You didnt choose a invite for the guild to join so the giveaway creation is now canceled!'));
            });
        }
        getInvite();
      });
    }

    function embed (description) {
      return new Discord.MessageEmbed()
        .setAuthor('Giveaways.wtf')
        .setColor('679ddb')
        .setDescription(description);
    }
  }
}

module.exports = CreateGiveaway;
